//
//  shapes.cpp
//  Lecture_17
//
//  Created by Leah Keating on 09/05/2025.
//

#include "shapes.hpp"

double area(double length){
    return length*length;
}

double area(double length, double width){
    return length*width;
}

double area(Square s){
    return s.length*s.length;
}

double area(Rectangle r){
    return r.length*r.width;
}

double area(Circle c){
    return PI*c.radius*c.radius;
}

// the :: scoping operator tells us that we are specifically referring to the area() method of Square
double Square::area(){
    return length*length;// because we are in the Square namespace (from Square::), we don't need to specify s.length as we did before.
}

double Rectangle::area(){
    return length*width;
}

double Circle::area(){
    return PI*radius*radius;
}
