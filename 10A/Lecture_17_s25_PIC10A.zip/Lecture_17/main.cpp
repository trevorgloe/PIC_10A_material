//
//  main.cpp
//  Lecture_17
//
//  Created by Leah Keating on 09/05/2025.
//

#include <iostream>
#include "shapes.hpp"
using namespace std;

/*
 - Overloaded functions
 - structs
 - Recorded lectures for Monday and Wednesday on BruinLearn
 */

int main() {
    
    // We want functions to calculate the area of different shapes
    // one option is overloaded functions
    // functions with the same name that take different arguments
    
    cout << "The area of a square with side length 4.2 is " << area(4.2) << endl;
    
    cout << "The area of a rectangle with lenght 1.1 and width 0.7 is " << area(1.1, 0.7) << endl;
    
    // If we try to do this for a circle, we will fail. This is because the signature for the area function for the circle is the same as the square, because they both just need 1 double argument. For the circle, this is its radius.
    
    Square s1; // declaring a square s1
    cout << "The lengths of the sides of s1 are " << s1.length << " (before initiaization.)\n";
    s1.length = 2.2;
    cout << "The lengths of the sides of s1 are " << s1.length << " (after initiaization.)\n";
    cout << "The area of s1 is " << area(s1) << endl;
    
    Rectangle r1;
    r1.length = 1.1;
    r1.width = 90;
    cout << "The area of rectangle with side lengths " << r1.length << " and " << r1.width << " is " << area(r1) << endl;
    
    Circle c1;
    c1.radius = 2.7;
    cout << "The area of the circle with radius " << c1.radius << " is " << area(c1) << endl;
    
    cout << "The area of square with side length " << s1.length << " is " << s1.area() << endl;
    cout << "The area of rectangle with sides " << r1.length << " and " << r1.width << " is " << r1.area() << endl;
    cout << "The area of a circle with radius " << c1.radius << " is " << c1.area() << endl;
    
    return 0;
}
