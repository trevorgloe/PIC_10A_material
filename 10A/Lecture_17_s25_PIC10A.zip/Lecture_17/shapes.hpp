//
//  shapes.hpp
//  Lecture_17
//
//  Created by Leah Keating on 09/05/2025.
//

#ifndef shapes_hpp
#define shapes_hpp

#include <stdio.h>

const double PI = 3.14159;

/**
 calculates the area of a square
 @param length the length of a side
 @return the area of the square
 */
double area(double length);

/**
 calculates the area of a rectangle
 @param length its length
 @param width its width
 @return the area of the rectangle
 */
double area(double length, double width);

// To fix the issue of not being able to do a circle area function, we introduce structs.
struct Square{
    double length;
    
    // add an area member method to the struct, this allows us to do s1.area() etc..
    // doesn't need arguments for things that are part of the struct (e.g., length)
    /**
     calculates the area of the square
     @return a double which represents the area
     */
    double area();
};

struct Rectangle{
    double length;
    double width;
    
    /**
     calculates the area of the rectangle
     @return a double which represents the area
     */
    double area();
};

struct Circle{
    double radius;
    
    /**
     calculates the area of the circle
     @return a double which represents the area
     */
    double area();
};

/**
 calculates the area of a square
 @param s a square struct
 @return the area of that square
 */
double area(Square s);

/**
 calculates the area of a rectangle
 @param r a rectangle struct
 @return the area of that rectangle
 */
double area(Rectangle r);

/**
 calculates the area of a circle
 @param c a circle struct
 @return the area of that circle
 */
double area(Circle c);

#endif /* shapes_hpp */
