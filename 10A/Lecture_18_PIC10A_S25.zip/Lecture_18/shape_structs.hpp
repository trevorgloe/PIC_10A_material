//
//  shape_structs.hpp
//  Lecture_18
//
//  Created by Leah Keating on 08/05/2025.
//

#ifndef shape_structs_hpp
#define shape_structs_hpp

#include <stdio.h>

const double PI = 3.14159;

struct Rectangle{
    double l1;
    double l2;
    
    Rectangle();
    Rectangle(double l);
    Rectangle(double _l1, double _l2);
    
    /**
     this function calculates the area of a rectangle object
     @return the area (a double)
     */
    double area();
};

struct Circle{
    double r;
    
    Circle();
    
    Circle(double _r);
    
    /**
     this function calculates the area of a circle object
     @return the area (a double)
     */
    double area();
};

#endif /* shape_structs_hpp */
