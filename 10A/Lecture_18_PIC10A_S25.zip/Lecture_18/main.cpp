//
//  main.cpp
//  Lecture_18
//
//  Created by Leah Keating on 08/05/2025.
//

#include <iostream>
#include "shape_structs.hpp"

using namespace std;

// CONSTRUCTORS

/*
 A CONSTRUCTOR is a special member function of a struct, and it is called when the struct is declared and used to initialise it.
 - It doesn't return anything.
 - It must always have the same name as the struct.
 - It can have parameters, if it does, these can be used to assign values to member variables.
 */

int main() {
    
    Rectangle r1;
    cout << "In r1, the defaults are l1 = " << r1.l1 << " and " << ", l2 = " << r1.l2 << endl;
    r1.l1 = 1.1;
    r1.l2 = 0.5;
    cout << "In r1, l1 = " << r1.l1 << " and " << ", l2 = " << r1.l2 << endl;
    cout << "The area of r1 is " << r1.area() << endl;
    
    // Setting up a rectangle by specifying 1 length
    Rectangle r2(2.4);
    cout << "In r2, l1 is " << r2.l1 << " and l2 is " << r2.l2 << endl;
    cout << "The area of r2 is " << r2.area() << endl;
    
    Rectangle r3(1.1, 2.0);
    cout << "In r3, l1 is " << r3.l1 << " and l2 is " << r3.l2 << endl;
    cout << "The area of r3 is " << r3.area() << endl;
    
    Circle c1;
    cout << "The circle with radius " << c1.r << " has area " << c1.area() << endl;
    
    Circle c2(1.2);
    cout << "The circle with radius " << c2.r << " has area " << c2.area() << endl;

    
    return 0;
}
