//
//  shape_structs.cpp
//  Lecture_18
//
//  Created by Leah Keating on 08/05/2025.
//

#include "shape_structs.hpp"
#include <cassert>

Rectangle::Rectangle(): l1(0), l2(0){}

Rectangle::Rectangle(double l):l1(l), l2(l){assert(l>=0);}

Rectangle::Rectangle(double _l1, double _l2):l1(_l1), l2(_l2){assert((_l1>=0) & (_l2>=0));}

double Rectangle::area(){// the :: is known as the scoping operator and this allows us to specifically define the area() method of the Rectangle struct
    return l1*l2;
}

Circle::Circle(): r(0){}
Circle::Circle(double _r):r(_r){assert(r>=0);}

double Circle::area(){
    return PI*r*r;
}
